/* =========================================
   0. SISTEMA DE TRADUÇÃO (MULTI-IDIOMA)
   ========================================= */
const translations = {
    pt: {
        nav_home: "Início",
        nav_about: "Sobre",
        nav_skills: "Skills",
        nav_projects: "Projetos",
        nav_contact: "Contactos",
        hero_hello: "Olá",
        hero_im: "O meu nome é",
        hero_desc: "Portefólio digital desenvolvido no âmbito da UFCD 10790 – Projeto de Programação.",
        btn_projects: "Ver Projetos",
        btn_contact: "Contactos",
        title_about: "Sobre Mim",
        
        // Textos longos do Sobre
        about_p1: "O meu nome é Afonso, sou um estudante na área da informática, com interesse em programação e desenvolvimento web. Ao longo da formação adquiri conhecimentos em HTML, CSS, Java, JavaScript, Python e C#.",
        about_p2: "Este portefólio foi desenvolvido no âmbito da UFCD 10790, com o objetivo de apresentar as minhas competências técnicas e alguns dos trabalhos realizados.",
        
        btn_cv: "Download CV",
        title_skills: "Skills Técnicas",
        title_projects: "Projetos",
        
        // Projetos
        proj1_title: "Portefólio Digital",
        proj1_desc: "Website pessoal desenvolvido com HTML, CSS e JavaScript, aplicando design responsivo e estrutura semântica.",
        proj2_title: "Projetos em Python",
        proj2_desc: "Exercícios e pequenas aplicações desenvolvidas no âmbito das aulas de programação.",
        proj3_title: "Projetos Académicos",
        proj3_desc: "Trabalhos realizados em diferentes disciplinas da área de informática, focados na lógica de programação e resolução de problemas.",
        
        title_contact: "Vamos Trabalhar Juntos?",
        btn_email: "Enviar Email",
        btn_instagram: "Instagram",

        // Máquina de escrever
        typing_words: ["Estudante de Informática ", "Front-End Developer ", "Entusiasta de Tecnologia "]
    },
    en: {
        nav_home: "Home",
        nav_about: "About",
        nav_skills: "Skills",
        nav_projects: "Projects",
        nav_contact: "Contact",
        hero_hello: "Hello",
        hero_im: "My name is",
        hero_desc: "Digital portfolio developed within the scope of UFCD 10790 – Programming Project.",
        btn_projects: "View Projects",
        btn_contact: "Contact Me",
        title_about: "About Me",
        
        // Textos longos do Sobre (Tradução)
        about_p1: "My name is Afonso, I am an IT student with an interest in programming and web development. Throughout my training, I have acquired knowledge in HTML, CSS, Java, JavaScript, Python, and C#.",
        about_p2: "This portfolio was developed within the scope of UFCD 10790, aimed at showcasing my technical skills and some of the work I have accomplished.",
        
        btn_cv: "Download CV",
        title_skills: "Technical Skills",
        title_projects: "Projects",
        
        // Projetos (Tradução)
        proj1_title: "Digital Portfolio",
        proj1_desc: "Personal website developed with HTML, CSS, and JavaScript, applying responsive design and semantic structure.",
        proj2_title: "Python Projects",
        proj2_desc: "Exercises and small applications developed during programming classes.",
        proj3_title: "Academic Projects",
        proj3_desc: "Assignments carried out in various IT subjects, focused on programming logic and problem-solving.",
        
        title_contact: "Let's Work Together?",
        btn_email: "Send Email", // Botão traduzido
        btn_instagram: "Instagram", // Botão traduzido

        // Máquina de escrever em Inglês
        typing_words: ["IT Student ", "Front-End Developer ", "Tech Enthusiast "]
    }
};

let currentLang = "pt"; 
let typeTimeout; // Variável para controlar o temporizador da máquina de escrever

const langBtn = document.getElementById("lang-switch");

// Função para mudar o idioma
langBtn.addEventListener("click", () => {
    currentLang = currentLang === "pt" ? "en" : "pt";
    langBtn.textContent = currentLang === "pt" ? "EN" : "PT";

    // 1. Atualiza todos os textos estáticos
    document.querySelectorAll("[data-lang]").forEach(element => {
        const key = element.getAttribute("data-lang");
        if (translations[currentLang][key]) {
            element.textContent = translations[currentLang][key];
        }
    });

    // 2. REINICIA A MÁQUINA DE ESCREVER (Correção do Bug)
    clearTimeout(typeTimeout); // Pára a animação atual imediatamente
    words = translations[currentLang].typing_words; // Carrega as novas palavras
    wordIndex = 0;
    charIndex = 0;
    isDeleting = false;
    const textElement = document.querySelector(".typing-text");
    if (textElement) {
        textElement.textContent = ""; // Limpa o texto visível
    }
    typeEffect(); // Arranca de novo
});


/* =========================================
   1. EFEITO MÁQUINA DE ESCREVER (Corrigido)
   ========================================= */
let words = translations["pt"].typing_words; 
let wordIndex = 0;
let charIndex = 0;
let isDeleting = false;

function typeEffect() {
    const textElement = document.querySelector(".typing-text");
    if (!textElement) return;

    const currentWord = words[wordIndex];
    
    if (isDeleting) {
        textElement.textContent = currentWord.substring(0, charIndex--);
    } else {
        textElement.textContent = currentWord.substring(0, charIndex++);
    }

    let typeSpeed = isDeleting ? 50 : 100;

    if (!isDeleting && charIndex === currentWord.length) {
        isDeleting = true;
        typeSpeed = 2000; 
    } else if (isDeleting && charIndex === 0) {
        isDeleting = false;
        wordIndex++;
        if (wordIndex === words.length) {
            wordIndex = 0;
        }
    }
    // Guardamos o ID do timeout para podermos cancelar se mudarem a língua
    typeTimeout = setTimeout(typeEffect, typeSpeed);
}

// Inicia a máquina ao carregar a página
document.addEventListener("DOMContentLoaded", typeEffect);


/* =========================================
   2. CARROSSEL DE IMAGENS 
   ========================================= */
const imagens = document.querySelectorAll(".hero-img img");
let indexAtual = 0;

if (imagens.length > 0) {
    function trocarImagem() {
        imagens[indexAtual].classList.remove('active');
        indexAtual++;
        if (indexAtual >= imagens.length) {
            indexAtual = 0;
        }
        imagens[indexAtual].classList.add('active');
    }
    setInterval(trocarImagem, 5000);
}

/* =========================================
   3. ANIMAÇÃO DAS BARRAS DE SKILLS (Replay)
   ========================================= */
const skillsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        const barras = entry.target.querySelectorAll(".nivel");
        
        if (entry.isIntersecting) {
            barras.forEach(barra => {
                const nivel = barra.getAttribute("data-nivel");
                barra.style.width = nivel + "%";
            });
        } else {
            barras.forEach(barra => {
                barra.style.width = "0%";
            });
        }
    });
}, { threshold: 0.3 });

const skillsSection = document.querySelector("#skills");
if (skillsSection) {
    skillsObserver.observe(skillsSection);
}

/* =========================================
   4. SCROLL REVEAL (Replay da entrada suave)
   ========================================= */
const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add("active");
        } else {
            entry.target.classList.remove("active");
        }
    });
}, { threshold: 0.1 });

document.querySelectorAll(".reveal").forEach(el => {
    revealObserver.observe(el);
});

/* =========================================
   5. BOTÃO VOLTAR AO TOPO
   ========================================= */
const toTopBtn = document.querySelector(".to-top");

window.addEventListener("scroll", () => {
    if (window.scrollY > 100) {
        toTopBtn.classList.add("active");
    } else {
        toTopBtn.classList.remove("active");
    }
});
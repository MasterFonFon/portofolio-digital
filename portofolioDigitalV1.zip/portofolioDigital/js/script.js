// Configuração do Observador
const observer = new IntersectionObserver((entries) => {

  entries.forEach(entry => {

    // Seleciona todas as barras dentro da secção que está a ser vigiada
    const barras = entry.target.querySelectorAll(".nivel");

    if (entry.isIntersecting) {
      // ESTÁ VISÍVEL: Enche as barras
      barras.forEach(barra => {
        const nivel = barra.getAttribute("data-nivel");
        barra.style.width = nivel + "%";
      });

    } else {
      // NÃO ESTÁ VISÍVEL: Reseta as barras a 0%
      // Isto garante que a animação funciona quando voltares a fazer scroll
      barras.forEach(barra => {
        barra.style.width = "0%";
      });
    }

  });

}, {
  threshold: 0.3 // A animação começa quando 30% da secção for visível
});

// Começar a vigiar todos os elementos que tenham a classe .animate
document.querySelectorAll(".animate").forEach(sec => {
  observer.observe(sec);
});
/* =========================================
   1. EFEITO MÁQUINA DE ESCREVER
   ========================================= */
document.addEventListener("DOMContentLoaded", function() {
    const textElement = document.querySelector(".typing-text");
    if (!textElement) return;

    const words = [
        "Estudante de Informática ", 
        "Front-End Developer ", 
        "Entusiasta de Tecnologia "
    ]; 

    let wordIndex = 0;
    let charIndex = 0;
    let isDeleting = false;

    function typeEffect() {
        const currentWord = words[wordIndex];
        
        if (isDeleting) {
            textElement.textContent = currentWord.substring(0, charIndex--);
        } else {
            textElement.textContent = currentWord.substring(0, charIndex++);
        }

        let typeSpeed = isDeleting ? 50 : 100;

        if (!isDeleting && charIndex === currentWord.length) {
            isDeleting = true;
            typeSpeed = 2000; 
        } else if (isDeleting && charIndex === 0) {
            isDeleting = false;
            wordIndex++;
            if (wordIndex === words.length) {
                wordIndex = 0;
            }
        }
        setTimeout(typeEffect, typeSpeed);
    }
    typeEffect();
});

/* =========================================
   2. CARROSSEL DE IMAGENS
   ========================================= */
const imagens = document.querySelectorAll(".hero-img img");
let indexAtual = 0;

if (imagens.length > 0) {
    function trocarImagem() {
        imagens[indexAtual].classList.remove('active');
        indexAtual++;
        if (indexAtual >= imagens.length) {
            indexAtual = 0;
        }
        imagens[indexAtual].classList.add('active');
    }
    setInterval(trocarImagem, 5000);
}

/* =========================================
   3. ANIMAÇÃO DAS BARRAS DE SKILLS (Replay)
   ========================================= */
const skillsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        const barras = entry.target.querySelectorAll(".nivel");
        
        if (entry.isIntersecting) {
            // Se a secção está visível, enche as barras
            barras.forEach(barra => {
                const nivel = barra.getAttribute("data-nivel");
                barra.style.width = nivel + "%";
            });
        } else {
            // Se a secção saiu do ecrã, esvazia as barras para 0
            // Assim, quando voltares, elas enchem de novo!
            barras.forEach(barra => {
                barra.style.width = "0%";
            });
        }
    });
}, { threshold: 0.3 });

const skillsSection = document.querySelector("#skills");
if (skillsSection) {
    skillsObserver.observe(skillsSection);
}

/* =========================================
   4. SCROLL REVEAL (Replay da entrada suave)
   ========================================= */
const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            // Entrou no ecrã: sobe e aparece
            entry.target.classList.add("active");
        } else {
            // Saiu do ecrã: esconde de novo
            // Isto garante que a animação repete quando voltares
            entry.target.classList.remove("active");
        }
    });
}, { threshold: 0.1 });

document.querySelectorAll(".reveal").forEach(el => {
    revealObserver.observe(el);
});

/* =========================================
   5. BOTÃO VOLTAR AO TOPO
   ========================================= */
const toTopBtn = document.querySelector(".to-top");

window.addEventListener("scroll", () => {
    // Se o scroll for maior que 100px, mostra o botão
    if (window.scrollY > 100) {
        toTopBtn.classList.add("active");
    } else {
        toTopBtn.classList.remove("active");
    }
});
